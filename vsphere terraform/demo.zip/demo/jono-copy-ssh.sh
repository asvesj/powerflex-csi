sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.191
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.192
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.193
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.194
