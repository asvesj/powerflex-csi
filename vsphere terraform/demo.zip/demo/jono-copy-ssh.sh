#remember to change the password to your new users password
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.10.10.191
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.10.10.192
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.10.10.193
sshpass -p jono ssh-copy-id -o StrictHostKeyChecking=no 10.10.10.194
