ssh-keygen -f $HOME/.ssh/id_rsa -t rsa -N ''
#enter the password of the root user
sshpass -p admin ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.191
sshpass -p admin ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.192
sshpass -p admin ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.193
sshpass -p admin ssh-copy-id -o StrictHostKeyChecking=no 10.213.121.194
